// ── SHOP PROFILE IMAGES (unique per shop) ──────────────────────────────────
export const SHOP_IMAGES = {
  1: 'https://images.unsplash.com/photo-1604719312566-8912e9667d9f?w=600&q=85',  // kirana / general
  2: 'https://images.unsplash.com/photo-1488459716781-31db52582fe9?w=600&q=85',  // vegetables
  3: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?w=600&q=85',     // dairy / milk
  4: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=600&q=85',     // provision store
  5: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?w=600&q=85',  // fruits
  6: 'https://images.unsplash.com/photo-1567306226416-28f0efdc88ce?w=600&q=85',  // bakery
  7: 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?w=600&q=85',  // rice / grains
  8: 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?w=600&q=85',  // fish
  9: 'https://images.unsplash.com/photo-1563636619-e9143da7973b?w=600&q=85',     // milk booth
 10: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=600&q=85', // spices
};

// Thumb versions for cards/recent chips
export const SHOP_THUMBS = {
  1: 'https://images.unsplash.com/photo-1604719312566-8912e9667d9f?w=200&q=75',
  2: 'https://images.unsplash.com/photo-1488459716781-31db52582fe9?w=200&q=75',
  3: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?w=200&q=75',
  4: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=200&q=75',
  5: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?w=200&q=75',
  6: 'https://images.unsplash.com/photo-1567306226416-28f0efdc88ce?w=200&q=75',
  7: 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?w=200&q=75',
  8: 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?w=200&q=75',
  9: 'https://images.unsplash.com/photo-1563636619-e9143da7973b?w=200&q=75',
 10: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=200&q=75',
};

// Category images for category tiles
export const CAT_IMAGES = {
  All:        'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=200&q=75',
  Kirana:     'https://images.unsplash.com/photo-1604719312566-8912e9667d9f?w=200&q=75',
  Vegetables: 'https://images.unsplash.com/photo-1488459716781-31db52582fe9?w=200&q=75',
  Dairy:      'https://images.unsplash.com/photo-1550583724-b2692b85b150?w=200&q=75',
  Provision:  'https://images.unsplash.com/photo-1542838132-92c53300491e?w=200&q=75',
  Fruits:     'https://images.unsplash.com/photo-1610832958506-aa56368176cf?w=200&q=75',
  Bakery:     'https://images.unsplash.com/photo-1567306226416-28f0efdc88ce?w=200&q=75',
  Grains:     'https://images.unsplash.com/photo-1578916171728-46686eac8d58?w=200&q=75',
};

// ── MOCK VENDORS (10 shops, rich data) ────────────────────────────────────
export const MOCK_VENDORS = [
  {
    id: 1, name: 'Ravi Kirana Store', category: 'Kirana',
    address: 'RS Puram, Coimbatore', distanceKm: 0.4,
    rating: 4.8, reviewCount: 124, trustScore: 94, viewCount: 87,
    status: 'open', hasIot: true, lastSeen: '2 min ago',
    openHours: '6:00 AM – 10:00 PM',
    phone: '+91 98765 43210',
    desc: 'Your trusted neighbourhood kirana store. Fresh stocks daily, competitive prices.',
    tags: ['Daily essentials', 'Bulk orders', 'Home delivery'],
  },
  {
    id: 2, name: 'Green Leaf Vegetables', category: 'Vegetables',
    address: 'Saibaba Colony, Coimbatore', distanceKm: 0.8,
    rating: 4.6, reviewCount: 89, trustScore: 91, viewCount: 63,
    status: 'open', hasIot: true, lastSeen: '5 min ago',
    openHours: '5:30 AM – 9:00 PM',
    phone: '+91 98876 54321',
    desc: 'Farm-fresh vegetables sourced directly from Ooty and Mettupalayam farms every morning.',
    tags: ['Farm fresh', 'Organic', 'Daily delivery'],
  },
  {
    id: 3, name: 'Amul Dairy Corner', category: 'Dairy',
    address: 'Peelamedu, Coimbatore', distanceKm: 1.1,
    rating: 4.5, reviewCount: 67, trustScore: 88, viewCount: 45,
    status: 'open', hasIot: true, lastSeen: '8 min ago',
    openHours: '5:00 AM – 8:00 PM',
    phone: '+91 97865 32190',
    desc: 'Authorised Amul distributor. Full range of dairy products — milk, curd, paneer, butter.',
    tags: ['Amul authorised', 'Pure milk', 'Paneer fresh'],
  },
  {
    id: 4, name: 'Sri Murugan Provision', category: 'Provision',
    address: 'Gandhipuram, Coimbatore', distanceKm: 1.3,
    rating: 4.3, reviewCount: 54, trustScore: 85, viewCount: 38,
    status: 'open', hasIot: false, lastSeen: 'N/A',
    openHours: '7:00 AM – 9:30 PM',
    phone: '+91 96543 21098',
    desc: 'All your monthly provisions — rice, dal, oil, spices — at wholesale prices.',
    tags: ['Wholesale rates', 'Bulk stock', 'Spices'],
  },
  {
    id: 5, name: 'Fresh Fruit Paradise', category: 'Fruits',
    address: 'Singanallur, Coimbatore', distanceKm: 1.6,
    rating: 4.7, reviewCount: 103, trustScore: 92, viewCount: 72,
    status: 'open', hasIot: true, lastSeen: '3 min ago',
    openHours: '6:00 AM – 9:00 PM',
    phone: '+91 98654 32109',
    desc: 'Seasonal fruits from across India. Mangoes, apples, grapes, and exotic varieties.',
    tags: ['Seasonal', 'Imported fruits', 'Juice packs'],
  },
  {
    id: 6, name: 'Kumar Bakery & Sweets', category: 'Bakery',
    address: 'Tatabad, Coimbatore', distanceKm: 1.9,
    rating: 4.6, reviewCount: 78, trustScore: 87, viewCount: 55,
    status: 'open', hasIot: false, lastSeen: 'N/A',
    openHours: '6:30 AM – 10:00 PM',
    phone: '+91 97654 21087',
    desc: 'Freshly baked bread, buns, cakes and traditional South Indian sweets every day.',
    tags: ['Fresh baked', 'Custom cakes', 'Sweets'],
  },
  {
    id: 7, name: 'Ponni Rice Traders', category: 'Grains',
    address: 'Ukkadam, Coimbatore', distanceKm: 2.1,
    rating: 4.4, reviewCount: 61, trustScore: 89, viewCount: 42,
    status: 'open', hasIot: true, lastSeen: '12 min ago',
    openHours: '8:00 AM – 8:00 PM',
    phone: '+91 98543 10976',
    desc: 'Premium rice varieties — Ponni, Sona Masoori, Basmati — at mill-direct prices.',
    tags: ['Mill direct', 'Premium rice', 'Bulk bags'],
  },
  {
    id: 8, name: 'Coastal Fish Market', category: 'Provision',
    address: 'Town Hall Road, Coimbatore', distanceKm: 2.4,
    rating: 4.2, reviewCount: 49, trustScore: 83, viewCount: 31,
    status: 'closed', hasIot: false, lastSeen: 'N/A',
    openHours: '5:00 AM – 11:00 AM',
    phone: '+91 96432 09875',
    desc: 'Fresh catch from Karur and Palladam markets. Rohu, Catla, Tilapia available daily.',
    tags: ['Fresh catch', 'Daily stock', 'Cleaned & cut'],
  },
  {
    id: 9, name: 'Aavin Milk Booth', category: 'Dairy',
    address: 'Vadavalli, Coimbatore', distanceKm: 2.7,
    rating: 4.5, reviewCount: 85, trustScore: 90, viewCount: 58,
    status: 'open', hasIot: true, lastSeen: '6 min ago',
    openHours: '5:00 AM – 7:00 AM & 4:30 PM – 7:00 PM',
    phone: '+91 97321 09865',
    desc: 'Official Aavin cooperative milk booth. Toned, standardised and full-cream variants.',
    tags: ['Govt cooperative', 'Pure milk', 'No additives'],
  },
  {
    id: 10, name: 'Spice Garden', category: 'Kirana',
    address: 'Race Course, Coimbatore', distanceKm: 3.0,
    rating: 4.9, reviewCount: 156, trustScore: 96, viewCount: 110,
    status: 'open', hasIot: true, lastSeen: '1 min ago',
    openHours: '7:00 AM – 10:30 PM',
    phone: '+91 98210 98765',
    desc: 'Premium spices and masalas direct from Idukki and Munnar. Freshly ground on demand.',
    tags: ['Freshly ground', 'Premium spices', 'Wholesale'],
  },
];

// ── MOCK PRODUCTS with prices per shop ─────────────────────────────────────
export const MOCK_PRODUCTS = [
  { id: 1,  name: 'Tomato',        unit: 'kg',  category: 'Vegetables', img: 'https://images.unsplash.com/photo-1546470427-e26264be0b0d?w=120&q=80' },
  { id: 2,  name: 'Onion',         unit: 'kg',  category: 'Vegetables', img: 'https://images.unsplash.com/photo-1508747703725-719777637510?w=120&q=80' },
  { id: 3,  name: 'Potato',        unit: 'kg',  category: 'Vegetables', img: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=120&q=80' },
  { id: 4,  name: 'Toned Milk',    unit: 'L',   category: 'Dairy',      img: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?w=120&q=80' },
  { id: 5,  name: 'Curd',          unit: 'kg',  category: 'Dairy',      img: 'https://images.unsplash.com/photo-1488477181946-6428a0291777?w=120&q=80' },
  { id: 6,  name: 'Rice (Ponni)',  unit: 'kg',  category: 'Provision',  img: 'https://images.unsplash.com/photo-1536304993881-ff86e0c9c3d7?w=120&q=80' },
  { id: 7,  name: 'Toor Dal',      unit: 'kg',  category: 'Provision',  img: 'https://images.unsplash.com/photo-1585996546047-21a8a01de2c6?w=120&q=80' },
  { id: 8,  name: 'Sunflower Oil', unit: 'L',   category: 'Provision',  img: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=120&q=80' },
  { id: 9,  name: 'Banana',        unit: 'doz', category: 'Fruits',     img: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=120&q=80' },
  { id: 10, name: 'Apple',         unit: 'kg',  category: 'Fruits',     img: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=120&q=80' },
];

// Price matrix [vendorId][productId] = price
export const PRICE_MATRIX = {
  1:  { 1: 40, 2: 32, 3: 28, 4: 52, 5: 46, 6: 62, 7: 88, 8: 138, 9: 36, 10: 180 },
  2:  { 1: 35, 2: 30, 3: 25, 4: 54, 5: 48, 6: 65, 7: 90, 8: 140, 9: 38, 10: 185 },
  3:  { 4: 50, 5: 44, 1: 42 },
  4:  { 6: 60, 7: 85, 8: 132, 1: 38, 2: 28 },
  5:  { 9: 34, 10: 175, 1: 44 },
  7:  { 6: 58, 7: 82, 8: 128 },
  9:  { 4: 48, 5: 42 },
  10: { 6: 64, 7: 92, 8: 142, 1: 36, 2: 26, 3: 22, 9: 32, 10: 170 },
};

// ── MOCK IOT DEVICES for admin ─────────────────────────────────────────────
export const MOCK_IOT_DEVICES = [
  { id: 'd1', vendorId: 1,  vendorName: 'Ravi Kirana Store',      model: 'ESP8266 NodeMCU', uptime: '99%', signal: '-65 dBm', lastSync: '2 min ago',  live: true  },
  { id: 'd2', vendorId: 2,  vendorName: 'Green Leaf Vegetables',  model: 'ESP32 DevKit',    uptime: '96%', signal: '-71 dBm', lastSync: '5 min ago',  live: true  },
  { id: 'd3', vendorId: 3,  vendorName: 'Amul Dairy Corner',      model: 'ESP8266 NodeMCU', uptime: '89%', signal: '-78 dBm', lastSync: '8 min ago',  live: true  },
  { id: 'd4', vendorId: 5,  vendorName: 'Fresh Fruit Paradise',   model: 'ESP32 DevKit',    uptime: '94%', signal: '-68 dBm', lastSync: '3 min ago',  live: true  },
  { id: 'd5', vendorId: 7,  vendorName: 'Ponni Rice Traders',     model: 'ESP8266 NodeMCU', uptime: '72%', signal: '-83 dBm', lastSync: '12 min ago', live: false },
  { id: 'd6', vendorId: 9,  vendorName: 'Aavin Milk Booth',       model: 'ESP32 DevKit',    uptime: '91%', signal: '-70 dBm', lastSync: '6 min ago',  live: true  },
  { id: 'd7', vendorId: 10, vendorName: 'Spice Garden',           model: 'ESP8266 NodeMCU', uptime: '98%', signal: '-62 dBm', lastSync: '1 min ago',  live: true  },
];

// Reviews per shop
export const MOCK_REVIEWS = {
  1: [
    { id: 1, userName: 'Priya S.', rating: 5, text: 'Always fresh stock and very helpful staff!', date: '2 days' },
    { id: 2, userName: 'Karthik R.', rating: 4, text: 'Good prices compared to other shops nearby.', date: '5 days' },
  ],
  2: [
    { id: 3, userName: 'Meena L.', rating: 5, text: 'Best vegetables in the area. Farm fresh every morning.', date: '1 day' },
    { id: 4, userName: 'Suresh P.', rating: 4, text: 'Quality is good but sometimes stock runs out early.', date: '3 days' },
  ],
  3: [
    { id: 5, userName: 'Anitha K.', rating: 5, text: 'Pure Amul products at official prices. Reliable.', date: '4 days' },
  ],
  5: [
    { id: 6, userName: 'Deepa M.', rating: 5, text: 'Imported fruits at reasonable prices. Loved the mangoes!', date: '1 day' },
    { id: 7, userName: 'Rajesh B.', rating: 4, text: 'Good variety. Wish they had more exotic fruits.', date: '6 days' },
  ],
  10: [
    { id: 8, userName: 'Lakshmi N.', rating: 5, text: 'Freshly ground spices — you can smell the difference!', date: '2 days' },
    { id: 9, userName: 'Venkat S.', rating: 5, text: 'Best spice shop in Coimbatore. Worth every rupee.', date: '4 days' },
  ],
};
